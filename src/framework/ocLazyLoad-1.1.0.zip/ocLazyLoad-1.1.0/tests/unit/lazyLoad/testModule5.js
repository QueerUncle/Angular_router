var testModule = angular.module('testModule5', []);

testModule.controller({
    "testModule5Ctrl": angular.noop
});
